from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from pathlib import Path

data_dir = Path(os.getenv("OZDEKAN_DATA_DIR", ".")).resolve()
data_dir.mkdir(parents=True, exist_ok=True)
database_path = data_dir / "logs.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///{database_path.as_posix()}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={
        "check_same_thread": False,
        "timeout": 60  # veritabanı 15 saniyeye kadar bekler
    }
)


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
